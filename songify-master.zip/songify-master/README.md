# songify
A Spotify-styled Songs App made using HTML, CSS and Javascript

Class 1 Starter Files: https://gist.github.com/avmain/3715a4bd0422e54e716db89b9ff9777a
Class 2 Starter Files: https://github.com/avmain/songify/tree/master/Javascript%20Class%202
Class 4 Starter Files: https://github.com/avmain/songify/tree/master/Javascript%20Class%204
